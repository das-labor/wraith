extern const char *vertexShader;
extern const char *spherePixelShader;
